<?php

$msg = '
            <html xmlns="http://www.w3.org/1999/xhtml">
                <head>
                    <title>CMA Mail</title><meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0;"><meta charset="utf-8" />
                    <style type="text/css">body{ width: 100%; background-color: #3a3c3a; margin: 0; padding: 0; -webkit-font-smoothing: antialiased; mso-margin-top-alt: 0px; mso-margin-bottom-alt: 0px; mso-padding-alt: 0px 0px 0px 0px;} p, h1, h2, h3, h4{ margin-top: 0; margin-bottom: 0; padding-top: 0; padding-bottom: 0;} span.preheader{ display: none; font-size: 1px;} html{ width: 100%;} table{ font-size: 12px; border: 0;} .menu-space{ padding-right: 25px;} table{ mso-table-lspace: 0pt; mso-table-rspace: 0pt;} img{ -ms-interpolation-mode: bicubic; border: none;} a, a:hover{ text-decoration: none; color: #FFF;} p{ text-align: left;} @media only screen and (max-width:640px){ body{ width: auto!important;} body[yahoo] table[class=main]{ width: 440px !important;} body[yahoo] table[class=two-left]{ width: 420px !important; margin: 0px auto;} body[yahoo] table[class=full]{ width: 100% !important; margin: 0px auto;} body[yahoo] table[class=alaine]{ text-align: center;} body[yahoo] table[class=menu-space]{ padding-right: 0px;} body[yahoo] table[class=banner]{ width: 438px !important;} body[yahoo] table[class=menu]{ width: 438px !important; margin: 0px auto; border-bottom: #e1e0e2 solid 1px;} body[yahoo] table[class=date]{ width: 438px !important; margin: 0px auto; text-align: center;} body[yahoo] table[class=two-left-inner]{ width: 400px !important; margin: 0px auto;} body[yahoo] table[class=menu-icon]{ display: block;} body[yahoo] table[class=two-left-menu]{ text-align: center;} p{ text-align: center;}} @media only screen and (max-width:479px){ body{ width: auto!important;} body[yahoo] table[class=main]{ width: 310px !important;} body[yahoo] table[class=two-left]{ width: 300px !important; margin: 0px auto;} body[yahoo] table[class=full]{ width: 100% !important; margin: 0px auto;} body[yahoo] table[class=alaine]{ text-align: center;} body[yahoo] table[class=menu-space]{ padding-right: 0px;} body[yahoo] table[class=banner]{ width: 308px !important;} body[yahoo] table[class=menu]{ width: 308px !important; margin: 0px auto; border-bottom: #e1e0e2 solid 1px;} body[yahoo] table[class=date]{ width: 308px !important; margin: 0px auto; text-align: center;} body[yahoo] table[class=two-left-inner]{ width: 280px !important; margin: 0px auto;} body[yahoo] table[class=menu-icon]{ display: none;} body[yahoo] table[class=two-left-menu]{ width: 310px !important; margin: 0px auto;} p{ text-align: center;}} </style>
    
                </head>
    
                <body yahoo="fix" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
    
                    <!--Main Table Start-->
    
                    <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#3a3c3a" style="background:#3a3c3a;">
                        <tbody>
                            <tr>
                                <td align="center" valign="top">
    
                                    <!--Logo part Start-->
    
                                    <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
                                        <tbody>
                                            <tr>
                                                <td align="center" valign="top">
                                                    <table width="700" border="0" align="center" cellpadding="0" cellspacing="0" class="main">
                                                        <tbody>
                                                            <tr>
                                                                <td align="left" valign="top" bgcolor="#9f8827a3" style="background:#9f8827a3;">
                                                                    <table width="630" border="0" align="center" cellpadding="0" cellspacing="0" class="two-left">
                                                                        <tbody>
                                                                            <tr>
                                                                                <td height="35" align="left" valign="top" style="line-height:35px;">&nbsp;</td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td align="left" valign="top">
    
    
                                                                                    <table width="135" border="0" align="left" cellpadding="0" cellspacing="0" class="two-left">
                                                                                        <tbody>
                                                                                            <tr>
                                                                                                <td align="center" valign="top">
                                                                                                    <table width="135" border="0" cellspacing="0" cellpadding="0">
                                                                                                        <tbody>
                                                                                                            <tr>
                                                                                                                <td width="27" align="left" valign="top">
                                                                                                                    <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
                                                                                                                        <tbody>
                                                                                                                            <tr>
                                                                                                                                <td align="center" valign="top">
                                                                                                                                    <a href="#"><img src="http://freetemplates.bz/design/smart/preview/images/facebook.png" width="20" height="20" alt=""></a>
                                                                                                                                </td>
                                                                                                                            </tr>
                                                                                                                        </tbody>
                                                                                                                    </table>
                                                                                                                </td>
                                                                                                                <td width="27" align="left" valign="top">
                                                                                                                    <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
                                                                                                                        <tbody>
                                                                                                                            <tr>
                                                                                                                                <td align="center" valign="top">
                                                                                                                                    <a href="#"><img src="http://freetemplates.bz/design/smart/preview/images/twitter.png" width="20" height="20" alt=""></a>
                                                                                                                                </td>
                                                                                                                            </tr>
                                                                                                                        </tbody>
                                                                                                                    </table>
                                                                                                                </td>
                                                                                                                <td width="27" align="left" valign="top">
                                                                                                                    <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
                                                                                                                        <tbody>
                                                                                                                            <tr>
                                                                                                                                <td align="center" valign="top">
                                                                                                                                    <a href="#"><img src="http://freetemplates.bz/design/smart/preview/images/google.png" width="20" height="20" alt=""></a>
                                                                                                                                </td>
                                                                                                                            </tr>
                                                                                                                        </tbody>
                                                                                                                    </table>
                                                                                                                </td>
                                                                                                                <td width="27" align="left" valign="top">
                                                                                                                    <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
                                                                                                                        <tbody>
                                                                                                                            <tr>
                                                                                                                                <td align="center" valign="top">
                                                                                                                                    <a href="#"><img src="http://freetemplates.bz/design/smart/preview/images/rss.png" width="20" height="20" alt=""></a>
                                                                                                                                </td>
                                                                                                                            </tr>
                                                                                                                        </tbody>
                                                                                                                    </table>
                                                                                                                </td>
                                                                                                                <td width="27" align="left" valign="top">
                                                                                                                    <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
                                                                                                                        <tbody>
                                                                                                                            <tr>
                                                                                                                                <td align="center" valign="top">
                                                                                                                                    <a href="#"><img src="http://freetemplates.bz/design/smart/preview/images/mail.png" width="20" height="20" alt=""></a>
                                                                                                                                </td>
                                                                                                                            </tr>
                                                                                                                        </tbody>
                                                                                                                    </table>
                                                                                                                </td>
                                                                                                            </tr>
                                                                                                        </tbody>
                                                                                                    </table>
                                                                                                </td>
                                                                                            </tr>
                                                                                            <tr>
                                                                                                <td height="35" align="left" valign="top" style="line-height:35px;">&nbsp;</td>
                                                                                            </tr>
                                                                                        </tbody>
                                                                                    </table>
    
                                                                                    <table width="405" border="0" align="right" cellpadding="0" cellspacing="0" class="two-left">
                                                                                        <tbody>
                                                                                            <tr>
                                                                                                <td align="left" valign="top">
    
    
                                                                                                    <table width="105" border="0" align="left" cellpadding="0" cellspacing="0" class="two-left">
                                                                                                        <tbody>
                                                                                                            <tr>
                                                                                                                <td align="center" valign="top">
                                                                                                                    <a href="#"><img src="http://claimsmanager.online/assets/img/logo_large_white.png" width="200" height="22" alt="" style="width: 200px;height: auto;"></a>
                                                                                                                </td>
                                                                                                            </tr>
                                                                                                            <tr>
                                                                                                                <td height="20" align="left" valign="top" style="line-height:20px;">&nbsp;</td>
                                                                                                            </tr>
                                                                                                        </tbody>
                                                                                                    </table>
    
                                                                                                    <table border="0" align="right" cellpadding="0" cellspacing="0" class="two-left">
                                                                                                        <tbody>
                                                                                                            <tr>
                                                                                                                <td align="center" valign="top" style="font-family:Arial, Helvetica, sans-serif; font-size:12px; font-weight:bold; text-transform:uppercase; color:#FFF; padding-top:4px;">
                                                                                                                    <a href="ERPcma.com.mx" style="text-decoration:none; color:#FFF;">Ir a sitio</a>
                                                                                                                </td>
                                                                                                            </tr>
                                                                                                            <tr>
                                                                                                                <td height="35" align="left" valign="top" style="line-height:35px;">&nbsp;</td>
                                                                                                            </tr>
                                                                                                        </tbody>
                                                                                                    </table>
    
    
                                                                                                </td>
                                                                                            </tr>
                                                                                        </tbody>
                                                                                    </table>
    
    
                                                                                </td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
    
                                    <!--Logo part End-->
    
    
                                    <!--Banner part Start-->
    
                                    <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
                                        <tbody>
                                            <tr>
                                                <td align="center" valign="top">
                                                    <table width="700" border="0" align="center" cellpadding="0" cellspacing="0" class="main">
                                                        <tbody>
                                                            <tr>
                                                                <td align="left" valign="top" bgcolor="#ae9a49" style="background:#ae9a49;">
    
                                                                    <table width="320" border="0" align="right" cellpadding="0" cellspacing="0" class="full">
                                                                        <tbody>
                                                                            <tr>
                                                                                <td align="center" valign="top"><img src="https://iconarchive.com/download/i5676/creative-freedom/shimmer/Document-Add.ico" width="320" height="435" alt="" style="display:block;width:100% !important; height:auto !important;"></td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
    
                                                                    <table width="350" border="0" cellspacing="0" cellpadding="0" class="full">
                                                                        <tbody>
                                                                            <tr>
                                                                                <td height="335" align="left" valign="bottom">
                                                                                    <table width="280" border="0" align="center" cellpadding="0" cellspacing="0">
                                                                                        <tbody>
                                                                                            <tr>
                                                                                                <td align="left" valign="top">
                                                                                                    <table width="105" border="0" align="left" cellpadding="0" cellspacing="0">
                                                                                                        <tbody>
                                                                                                            <tr>
                                                                                                                <td width="95" align="left" valign="top" style="font-family:Arial, Helvetica, sans-serif; font-size:14px; font-weight:bold; text-transform:uppercase; color:#FFF;"><a href="#" style="text-decoration:none; color:#FFF;">Ir al ID </a></td>
                                                                                                                <td width="10" align="center" valign="middle"><img src="http://freetemplates.bz/design/smart/preview/images/read-more.png" width="10" height="10" alt="" style="display:block;"></td>
                                                                                                            </tr>
                                                                                                        </tbody>
                                                                                                    </table>
                                                                                                </td>
                                                                                            </tr>
                                                                                            <tr>
                                                                                                <td align="left" valign="top" style="font-family:Arial, Helvetica, sans-serif; font-size:36px; font-weight:bold; text-transform:uppercase; color:#FFF; line-height:48px; padding-top:16px;">Se acaba de crear el ID 101-054-22.</td>
                                                                                            </tr>
                                                                                            <tr>
                                                                                                <td height="50" align="left" valign="top" style="line-height:50px;">&nbsp;</td>
                                                                                            </tr>
                                                                                        </tbody>
                                                                                    </table>
                                                                                </td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
    
    
    
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
    
                                    <!--Banner part End-->
    
    
                                    <!--Welcome part Start-->
    
                                    <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
                                        <tbody>
                                            <tr>
                                                <td align="center" valign="top">
                                                    <table width="700" border="0" align="center" cellpadding="0" cellspacing="0" class="main">
                                                        <tbody>
                                                            <tr>
                                                                <td align="left" valign="top" bgcolor="#9f8827a3" style="background:#9f8827a3;">
                                                                    <table width="530" border="0" align="center" cellpadding="0" cellspacing="0" class="two-left">
                                                                        <tbody>
                                                                            <tr>
                                                                                <td height="95" align="left" valign="top" style="line-height:95px;">&nbsp;</td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td align="center" valign="top">
                                                                                    <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
                                                                                        <tbody>
                                                                                            <tr>
                                                                                                <td align="center" valign="top">
                                                                                                    <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
                                                                                                        <tbody>
                                                                                                            <tr>
                                                                                                                <td align="center" valign="top" style="font-family:Arial, Helvetica, sans-serif; font-size:18px; font-weight:bold; text-transform:uppercase; color:#FFF;">Se ha asignado al área de </td>
                                                                                                            </tr>
                                                                                                            <tr>
                                                                                                                <td align="center" valign="top" style="font-family:Arial, Helvetica, sans-serif; font-size:50px; font-weight:bold; text-transform:uppercase; color:#FFF; padding:10px 0px 15px 0px;">Siniestros</td>
                                                                                                            </tr>
                                                                                                        </tbody>
                                                                                                    </table>
                                                                                                </td>
                                                                                            </tr>
                                                                                            <tr>
                                                                                                <td align="center" valign="top" style="font-family:Verdana, Geneva, sans-serif; font-size:16px; font-weight:normal;color:#FFF; line-height:36px; padding-bottom:15px;">
                                                                                                    fecha de creación:
                                                                                                    <?=core::getNow()?> ;
                                                                                                        <br>fecha de asignacion:
                                                                                                        <?=core::getNow()?> ;
                                                                                                </td>
                                                                                            </tr>
                                                                                            <tr>
                                                                                                <td align="center" valign="top">
                                                                                                    <table width="185" border="0" align="center" cellpadding="0" cellspacing="0">
                                                                                                        <tbody>
                                                                                                            <tr>
                                                                                                                <td align="center" valign="top">&nbsp;</td>
                                                                                                            </tr>
                                                                                                            <tr>
                                                                                                                <td height="45" align="center" valign="middle" style=" border:#ffffff solid 2px; font-family:Arial, Helvetica, sans-serif; font-size:18px; font-weight:bold; text-transform:uppercase; color:#FFF;"><a href="#" style="text-decoration:none; color:#FFF;">Ver ID</a></td>
                                                                                                            </tr>
                                                                                                        </tbody>
                                                                                                    </table>
                                                                                                </td>
                                                                                            </tr>
                                                                                        </tbody>
                                                                                    </table>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td height="95" align="left" valign="top" style="line-height:95px;">&nbsp;</td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
    
                                    <!--Welcome part End-->
    
                                    <!--contact-image Start-->
    
                                    <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
                                        <tbody>
                                            <tr>
                                                <td align="center" valign="top">
                                                    <table width="700" border="0" align="center" cellpadding="0" cellspacing="0" class="main">
                                                        <tbody>
                                                            <tr>
                                                                <td align="left" valign="top" bgcolor="#FFFFFF" style="background:#FFF;"><img src="http://claimsmanager.online/assets/img/bg/1.1.jpg" width="700" height="310" alt="" style="display:block;width:100% !important; height:auto !important;"></td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
    
                                    <!--contact-image End-->
    
                                    <!--contact-Text Start-->
    
                                    <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
                                        <tbody>
                                            <tr>
                                                <td align="center" valign="top">
                                                    <table width="700" border="0" align="center" cellpadding="0" cellspacing="0" class="main">
                                                        <tbody>
                                                            <tr>
                                                                <td align="left" valign="top" bgcolor="#9f8827a3" style="background:#9f8827a3;">
                                                                    <table width="580" border="0" align="center" cellpadding="0" cellspacing="0" class="two-left">
                                                                        <tbody>
                                                                            <tr>
                                                                                <td height="60" align="left" valign="top" style="line-height:60px;">&nbsp;</td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td align="left" valign="top">
    
                                                                                    <table width="240" border="0" align="left" cellpadding="0" cellspacing="0" class="two-left">
                                                                                        <tbody>
                                                                                            <tr>
                                                                                                <td align="left" valign="top" style="font-family:Arial, Helvetica, sans-serif; font-size:16px; font-weight:bold; text-transform:uppercase; color:#FFF;">Contacto</td>
                                                                                            </tr>
    
                                                                                            <tr>
                                                                                                <td align="left" valign="top" style="font-family:Verdana, Geneva, sans-serif; font-size:14px; font-weight:normal;color:#FFF; line-height:30px; padding-top:10px; padding-bottom:40px;">Mail : contacto@cma.com<br> Call : 1800-956-63254</td>
                                                                                            </tr>
    
                                                                                            <tr>
                                                                                                <td align="left" valign="top" style="font-family:Verdana, Geneva, sans-serif; font-size:14px; font-weight:normal;color:#FFF; line-height:30px; padding-top:10px; padding-bottom:40px;">Mail : admin@cma.com<br> Call : 1800-956-456</td>
                                                                                            </tr>
                                                                                        </tbody>
                                                                                    </table>
    
    
                                                                                    <table width="280" border="0" align="right" cellpadding="0" cellspacing="0" class="two-left">
                                                                                        <tbody>
                                                                                            <tr>
                                                                                                <td align="left" valign="top">
                                                                                                    <table width="280" border="0" align="left" cellpadding="0" cellspacing="0" class="two-left">
                                                                                                        <tbody>
                                                                                                            <tr>
                                                                                                                <td align="left" valign="top" style="font-family:Arial, Helvetica, sans-serif; font-size:16px; font-weight:bold; text-transform:uppercase; color:#FFF;">CMA administración de siniestros</td>
                                                                                                            </tr>
                                                                                                            <tr>
                                                                                                                <td align="left" valign="top" style="font-family:Verdana, Geneva, sans-serif; font-size:14px; font-weight:normal;color:#FFF; line-height:30px; padding-top:10px; padding-bottom:20px;">Este email se ha enviado de forma automatica por que estás asignado al mismo, o eres jefe del area asignada, si al ingresar por medio de este mail, ya no visualisas
                                                                                                                    el contenido, es probable que se haya reasignado el siniestro a otra área o abogado.</td>
                                                                                                            </tr>
                                                                                                            <tr>
                                                                                                                <td align="left" valign="top">
                                                                                                                    <table width="105" border="0" align="left" cellpadding="0" cellspacing="0">
                                                                                                                        <tbody>
                                                                                                                            <tr>
                                                                                                                                <td width="95" align="left" valign="top" style="font-family:Arial, Helvetica, sans-serif; font-size:14px; font-weight:bold; text-transform:uppercase; color:#FFF;"><a href="#" style="text-decoration:none; color:#FFF;">Ir a CMA App </a></td>
                                                                                                                                <td width="10" align="center" valign="middle"><img src="http://freetemplates.bz/design/smart/preview/images/read-more.png" width="10" height="10" alt="" style="display:block;"></td>
                                                                                                                            </tr>
                                                                                                                        </tbody>
                                                                                                                    </table>
                                                                                                                </td>
                                                                                                            </tr>
                                                                                                        </tbody>
                                                                                                    </table>
                                                                                                </td>
                                                                                            </tr>
                                                                                        </tbody>
                                                                                    </table>
    
    
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td height="40" align="left" valign="top" style="line-height:40px;">&nbsp;</td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
    
                                    <!--contact-Text End-->
    
    
                                    <!--copyright Start-->
    
                                    <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
                                        <tbody>
                                            <tr>
                                                <td align="center" valign="top">
                                                    <table width="700" border="0" align="center" cellpadding="0" cellspacing="0" class="main">
                                                        <tbody>
                                                            <tr>
                                                                <td align="left" valign="top" bgcolor="#ae9a49" style="background:#ae9a49;">
                                                                    <table width="580" border="0" align="center" cellpadding="0" cellspacing="0" class="two-left">
                                                                        <tbody>
                                                                            <tr>
                                                                                <td height="60" align="left" valign="middle" style="font-family:Verdana, Geneva, sans-serif; font-size:12px; font-weight:normal;color:#FFF;">Copyright © 2022 smart mail. información confidencial. power by asicomgraphics.mx</td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
    
                                    <!--copyright End-->
    
    
                                </td>
                            </tr>
                        </tbody>
                    </table>
    
                    <!--Main Table End-->
    
    
    
                </body>
    
</html>';
// echo $msg;
core::preprint('hola');
//$email = "erick.leo.malagon@gmail.com";
$subject = 'probando mail';
// require_once "./core/controller/Correo.php";
Correo::sendMail($msg,$email,$subject,$debug=0);