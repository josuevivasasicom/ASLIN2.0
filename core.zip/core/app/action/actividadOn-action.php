<?php 

$intermitente = $_SESSION['id'];

print $intermitente;