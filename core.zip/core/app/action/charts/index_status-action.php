<?php
$resp= Siniestros::datosGraficasIndexStatus(); //imprime el json 