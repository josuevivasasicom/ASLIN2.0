<?php
$resp= Siniestros::datosGraficasIndex(); //imprime el json 