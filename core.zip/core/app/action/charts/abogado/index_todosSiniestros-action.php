<?php
$resp= SiniestrosAbogado::datosGraficasIndex(); //imprime el json 