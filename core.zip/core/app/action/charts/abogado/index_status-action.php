<?php
$resp= SiniestrosAbogado::datosGraficasIndexStatus(); //imprime el json 
//var_dump($resp);
