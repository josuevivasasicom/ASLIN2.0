<?php
$resp= SiniestrosAbogado::datosGraficasIndexID(); //imprime el json 