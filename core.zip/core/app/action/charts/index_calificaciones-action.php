<?php
$resp= Siniestros::datosGraficasIndexCalificaciones(); //imprime el json 