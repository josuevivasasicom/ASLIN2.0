<?php
$resp= UserData::datosGraficasIndexUsuarios(); //imprime el json 