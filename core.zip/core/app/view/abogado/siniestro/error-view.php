<div class="content">
        <div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="card-header">
                <h5 class="card-title">OPS! algo salió mal</h5>
                <p class="card-category">Por favor cierra esta ventana e intentalo nuevamente.</p>
              </div>
              <div class="card-body">
                <div class="row">
                <div class="col">
                    <div class="card card-plain">
                        <div class="alert alert-danger alert-dismissible fade show">
                          <button type="button" aria-hidden="true" class="close" data-dismiss="alert" aria-label="Close">
                            <i class="nc-icon nc-simple-remove"></i>
                          </button>
                          <span><b> ERROR - </b> Posiblemente estes realizando una acción que requeiere permisos sobre el ID y no los tienes, o estes realizando una busqueda de un folio que no existe."</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>